package com.hsbc.chinainnovation.antifraud.controller;

import com.hsbc.chinainnovation.antifraud.util.ConstantUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class JumpPageController
{
    @RequestMapping("/index")
    public String index()
    {
        return "index";
    }

    @RequestMapping("/login")
    public String login()
    {
        return "login";
    }

    @RequestMapping("/changePassWord")
    public String changePassWord()
    {
        return "changePassWord";
    }

    @RequestMapping("/adminPage")
    public String configPage(HttpServletRequest request)
    {
        String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        if(null != account && "admin".equals(account))
        {
            return "adminPage";
        }
        return "redirect:login";
    }
}
