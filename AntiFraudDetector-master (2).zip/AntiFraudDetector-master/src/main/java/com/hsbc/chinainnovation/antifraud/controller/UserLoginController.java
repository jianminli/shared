package com.hsbc.chinainnovation.antifraud.controller;

import com.hsbc.chinainnovation.antifraud.service.LoginRegisterService;
import com.hsbc.chinainnovation.antifraud.util.ConstantUtil;
import com.hsbc.chinainnovation.antifraud.util.Log;
import com.hsbc.chinainnovation.antifraud.util.MD5Util;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@CrossOrigin
@RequestMapping(value = "/")
public class UserLoginController {

    @Resource
    private LoginRegisterService loginRegisterService;

    @GetMapping("/loginCheckUser")
    @ResponseBody
    public String loginCheckUser(HttpSession session)
    {
        if (session.getAttribute(ConstantUtil.SESSION_KEY) != null)
        {
            return "TRUE";
        }
        return "FAIL";
    }

    @GetMapping("/logout")
    @ResponseBody
    public String logout(HttpSession session)
    {
        session.removeAttribute(ConstantUtil.SESSION_KEY);
        return "SUCCESS";
    }

    @PostMapping("/loginCheck")
    public @ResponseBody Map<String,String> loginPost(@RequestBody Map<String,Object> reqMap,HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String account = reqMap.get("account").toString();
        String password = reqMap.get("password").toString();
        boolean flag = loginRegisterService.readUserInfoFromFile(account,MD5Util.getMD5(password),map);
        if(flag)
        {
            if(request.getSession().getAttribute(ConstantUtil.SESSION_KEY) != null)
            {
                request.getSession().removeAttribute(ConstantUtil.SESSION_KEY);
            }
            request.getSession().setAttribute(ConstantUtil.SESSION_KEY, account);
            request.getSession().setMaxInactiveInterval(1200);
            map.put("account",account);
        }
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:Login|result:"+map);
        return map;
    }

    /**
     * 注册
     * */
    @PostMapping("/loginRegister")
    public @ResponseBody Map<String,String> registerPost(@RequestBody Map<String,Object> reqMap, HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String account = reqMap.get("account").toString().trim();
        String password = reqMap.get("password").toString();
        String flagLogin = loginRegisterService.checkAccountIsExist(account);
        if(!"FAIL".equalsIgnoreCase(flagLogin))
        {
            map.put("flag","FAIL");
            map.put("message","This account already exists");
            Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:Register|result:"+map);
            return map;
        }

        boolean flagRegister = loginRegisterService.writeUserInfoToFile(account+":"+ MD5Util.getMD5(password)+":"+ConstantUtil.USER_STATUS_NO);
        if(flagRegister)
        {
            map.put("flag","SUCCESS");
            map.put("message","Register Success,Please contact the administrator for approval");
            map.put("account",account);
            Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                    +"|Account:"+account+"|Action:Register|result:"+map);
            return map;
        }
        map.put("flag","FAIL");
        map.put("message","Register fail,Please refresh the page and try again");
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:Register|result:"+map);
        return map;
    }

    @GetMapping("/getAllUserInfo")
    public @ResponseBody List<Map<String,String>> getAllUserInfo(HttpServletRequest request)
    {
        String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:View user info");
        return loginRegisterService.getAllUserInfo();
    }

    @PostMapping("/updateUserInfoStatus")
    public @ResponseBody Map<String,String> updateUserInfoStatus(@RequestBody Map<String,Object> reqMap,HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String account = reqMap.get("account").toString();
        String flag = reqMap.get("flag").toString();
        String loginAccount = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        map.put("account",account);
        //验证账号是否存在
        String flagLogin = loginRegisterService.checkAccountIsExist(account);
        if("FAIL".equalsIgnoreCase(flagLogin))
        {
            map.put("flag","FAIL");
            map.put("message","This account does not exist, please refresh the page and try again");
            Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                    +"|Account:"+loginAccount+"|Action:change user status to "+flag+"|result:"+map);
            return map;
        }
        String newStr = flagLogin.substring(0,flagLogin.lastIndexOf(":")+1)+flag;
        //更改用户状态
        boolean updateFlag = loginRegisterService.replaceTxtByStr(flagLogin,newStr);
        if(updateFlag)
        {
            map.put("flag","SUCCESS");
            map.put("message","User status change is successful");
        }
        else
        {
            map.put("flag","FAIL");
            map.put("message","User status change is failed, please refresh the page and try again");
        }
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+loginAccount+"|Action:change user status to "+flag+"|result:"+map);
        return map;
    }

    @PostMapping("/updateUserInfoPassword")
    public @ResponseBody Map<String,String> updateUserInfoPassword(@RequestBody Map<String,Object> reqMap,HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        if(reqMap.get("new_password") == null && reqMap.get("old_password") == null)
        {
            map.put("message","Old password and new password cannot be empty!");
        }
        String newPassword = reqMap.get("new_password").toString();
        String oldPassword = reqMap.get("old_password").toString();
        if(StringUtils.isEmptyOrWhitespace(newPassword) && StringUtils.isEmptyOrWhitespace(oldPassword))
        {
            map.put("message","Old password and new password cannot be empty!");
        }
        if(newPassword.equals(oldPassword))
        {
            map.put("message","The old password cannot be the same as the new password!");
        }
        map.put("account",account);
        boolean flag = loginRegisterService.readUserInfoFromFile(account,MD5Util.getMD5(oldPassword),map);
        if(flag)
        {
            String newStr = account+":"+MD5Util.getMD5(newPassword)+":"+ConstantUtil.USER_STATUS_YES;
            String flagLogin = loginRegisterService.checkAccountIsExist(account);
            boolean updateFlag = loginRegisterService.replaceTxtByStr(flagLogin,newStr);
            if(updateFlag)
            {
                map.put("message","Change password success");
            }
            else
            {
                map.put("message","Change password failed, please refresh the page and try again");
            }
        }
        else
        {
            map.put("message","old password entered incorrectly");
        }
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:change password|result:"+map);
        return map;
    }

    @PostMapping("/deleteUserInfo")
    public @ResponseBody Map<String,String> deleteUserInfo(@RequestBody String account,HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String loginAccount = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        map.put("account",account);
        String flagLogin = loginRegisterService.checkAccountIsExist(account);
        if("FAIL".equalsIgnoreCase(flagLogin)) {
            map.put("flag", "FAIL");
            map.put("message", "This account does not exist");
        }
        else
        {
            //备份文件
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
            String newFilePath = ConstantUtil.USRE_INFOS_PATH+df.format(new Date())+"_userinfo.txt";
            boolean copyFlag = loginRegisterService.copyFile(ConstantUtil.USRE_INFO_PATH,newFilePath);
           if(!copyFlag)
           {
               map.put("flag", "FAIL");
               map.put("message", "File backup failed, please refresh the page and try again");
           }
           else
           {
               //删除多余备份文件
               loginRegisterService.getWillDeleteFile(loginRegisterService.getFileName
                       (ConstantUtil.USRE_INFOS_PATH),ConstantUtil.USRE_INFOS_PATH,ConstantUtil.USER_BACKUP_FILE_10);
                //更改用户状态
                boolean updateFlag = loginRegisterService.replaceTxtByStr(flagLogin,"");
                if(updateFlag)
                {
                    map.put("flag", "SUCCESS");
                    map.put("message", "delete user success");
                }
                else
                {
                    map.put("flag", "FAIL");
                    map.put("message", "delete user failed, please refresh the page and try again");
                }
           }
        }
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+loginAccount+"|Action:delete user|result:"+map);
        return map;
    }


    @GetMapping("/getAntiFraudConfigInfo")
    public @ResponseBody List<Map<String,String>> getAntiFraudConfigInfo(HttpServletRequest request)
    {
        String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:View API Config Info");
        List<Map<String,String>> configInfoList = new ArrayList<>();
        List<Map<String,String>> configPathList = getConfigInfo();
        for (Map<String,String> map : configPathList)
        {
            Map<String,String> antiFraudMap = loginRegisterService.getAntiFraudConfigInfo(map.get("configUrl"),map.get("configName"));
            if(antiFraudMap != null && !antiFraudMap.isEmpty())
            {
                configInfoList.add(antiFraudMap);
            }
        }
        return configInfoList;
    }
    private  List<Map<String,String>> getConfigInfo()
    {
        List<Map<String,String>> configList = new ArrayList<>();
        Map<String,String> configMap = new HashMap<>();
        configMap.put("configName","AntiFraud");
        configMap.put("configUrl",ConstantUtil.ANTI_FRAUD_CONFIG_INFO_PATH);
        configList.add(configMap);
        configMap = new HashMap<>();
        configMap.put("configName","AntiAdress");
        configMap.put("configUrl",ConstantUtil.ANTI_ADDRESS_CONFIG_INFO_PATH);
        configList.add(configMap);
        configMap = new HashMap<>();
        configMap.put("configName","UM");
        configMap.put("configUrl",ConstantUtil.UM_CONFIG_INFO_PATH);
        configList.add(configMap);
        configMap = new HashMap<>();
        configMap.put("configName","MBA");
        configMap.put("configUrl",ConstantUtil.MBA_CONFIG_INFO_PATH);
        configList.add(configMap);
        return configList;
    }

    @PostMapping("/updateAntiFraudConfigInfo")
    public @ResponseBody Map<String,String> updateAntiFraudConfigInfo(@RequestBody Map<String,Object> reqMap,HttpServletRequest request)
    {
        Map<String,String> map = new HashMap<>();
        String loginAccount = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        map.put("account",loginAccount);
        if(reqMap == null || reqMap.isEmpty())
        {
            map.put("flag", "FAIL");
            map.put("message", "The Requested API Config Parameter is null");
            return map;
        }
        for (Map.Entry<String,Object> entry : reqMap.entrySet())
        {
            if("key".equalsIgnoreCase(entry.getKey()))
            {
                continue;
            }
            if(entry.getValue() == null || entry.getValue() =="")
            {
                map.put("flag", "FAIL");
                map.put("message", "API Config Parameter:"+entry.getKey()+" is null");
                return map;
            }
        }
        String fileName;
        String filePath;
        String apiType;
        if("AntiFraud".equalsIgnoreCase(reqMap.get("antiTab").toString()))
        {
            apiType = "Anti-Fraud";
            fileName = "AntiFraudConfigInfo.txt";
            filePath = ConstantUtil.ANTI_FRAUD_CONFIG_INFO_PATH;
        }
        else if("AntiAdress".equalsIgnoreCase(reqMap.get("antiTab").toString()))
        {
            apiType = "Adress Validation";
            fileName = "AntiAddressConfigInfo.txt";
            filePath = ConstantUtil.ANTI_ADDRESS_CONFIG_INFO_PATH;
        }
        else if("UM".equalsIgnoreCase(reqMap.get("antiTab").toString()))
        {
            apiType = "Underground Market";
            fileName = "UMConfigInfo.txt";
            filePath = ConstantUtil.UM_CONFIG_INFO_PATH;
        }
        else if("MBA".equalsIgnoreCase(reqMap.get("antiTab").toString()))
        {
            apiType = "Multi-banking Account";
            fileName = "MBAConfigInfo.txt";
            filePath = ConstantUtil.MBA_CONFIG_INFO_PATH;
        }
        else
        {
            map.put("flag", "FAIL");
            map.put("message", "Can't distinguish which API!");
            return null;
        }
        if(reqMap.get("key") == null || "".equals(reqMap.get("key")) || "123456".equals(reqMap.get("key")))
        {
            reqMap.put("key",ConstantUtil.getAPIConfigKeyInfo(filePath));
        }
        //备份文件
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        String newFilePath = ConstantUtil.ANTI_CONFIG_INFOS_PATH+df.format(new Date())+"_"+fileName;
        boolean copyFlag = loginRegisterService.copyFile(filePath,newFilePath);
        if(!copyFlag)
        {
            map.put("flag", "FAIL");
            map.put("message", "API("+apiType+") Config File backup failed, please refresh the page and try again");
        }
        else
        {
            //删除多余备份文件
            loginRegisterService.getWillDeleteFile(loginRegisterService.getFileName(
                    ConstantUtil.ANTI_CONFIG_INFOS_PATH),ConstantUtil.ANTI_CONFIG_INFOS_PATH,ConstantUtil.USER_BACKUP_FILE_100);
            //更改配置文件
            boolean updateFlag = loginRegisterService.updateAntiFraudConfigInfo(reqMap,filePath);
            if(updateFlag)
            {
                map.put("flag", "SUCCESS");
                map.put("message", "update API("+apiType+") Config Info success");
            }
            else
            {
                map.put("flag", "FAIL");
                map.put("message", "update API("+apiType+") Config Info failed, please refresh the page and try again");
            }
        }

        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+loginAccount+"|Action:update API("+apiType+") Config Info|result:"+map);
        return map;
    }

    @GetMapping("/getUserLogInfo")
    public List<Map<String,String>> getUserLogInfo(HttpServletRequest request)
    {
        List<Map<String,String>> result = loginRegisterService.getAllUserLogInfo();
        String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
        Log.t("USER_RECORD|IP:"+ ConstantUtil.getClientIP(request)
                +"|Account:"+account+"|Action:View User Record Log info");
        return result;
    }
}
