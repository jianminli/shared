package com.hsbc.chinainnovation.antifraud.controller;

import com.hsbc.chinainnovation.antifraud.entity.UserAddress;
import com.hsbc.chinainnovation.antifraud.entity.UserInfo;
import com.hsbc.chinainnovation.antifraud.service.UserRiskService;
import com.hsbc.chinainnovation.antifraud.util.ConstantUtil;
import com.hsbc.chinainnovation.antifraud.util.Log;
import com.hsbc.chinainnovation.antifraud.util.MD5Util;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Jay
 */
@RestController
@CrossOrigin
@RequestMapping(value = "/userRisk")
public class UserRiskController
{
	@Resource
	private UserRiskService userRiskService;

	@PostMapping("/getUserInfo")
	public String getUserInfo(@RequestBody UserInfo userInfo, HttpServletRequest request)
	{
		if(null == userInfo || null == userInfo.getRequest_url() || null == userInfo.getRequest_type())
		{
			return "parameter is null";
		}
		String requestType = userInfo.getRequest_type();
		String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
		String clientIP = ConstantUtil.getClientIP(request);
		Log.t("USER_RECORD|IP:"+clientIP
				+"|Account:"+account+"|Action:("+requestType+")("+ConstantUtil.API_FRAUD_FULL+")"+userInfo.getRequest_url());
		if(userInfo.getKey() == null || "".equals(userInfo.getKey()) || "123456".equals(userInfo.getKey()))
		{
			userInfo.setKey(ConstantUtil.getAPIConfigKeyInfo(ConstantUtil.ANTI_FRAUD_CONFIG_INFO_PATH));
		}
		String sign = "datetime="+userInfo.getDatetime()+"&identity="+userInfo.getIdentity()
				+"&name="+userInfo.getName()+"&phone="+userInfo.getPhone()+"&reqid="+userInfo.getReqid()
				+"&service_id="+userInfo.getService_id()+"&sign_type="+userInfo.getSign_type()
				+"&sp_no="+userInfo.getSp_no()+"&key="+userInfo.getKey()+"";

		String result = getApiResponse(userInfo,sign,account,clientIP,ConstantUtil.API_FRAUD_FULL);

		Log.t("USER_API|IP:"+clientIP + "|Account:"+account
				+"|Action:("+requestType+")("+ConstantUtil.API_FRAUD_FULL+")"+userInfo.getRequest_url()+"|result:"+result);
		return result;
	}

	@PostMapping("/getUserAddress")
	public String getUserAddress(@RequestBody UserAddress userAddress, HttpServletRequest request)
	{
		if(userAddress == null || null == userAddress.getRequest_url() || null == userAddress.getRequest_type())
		{
			return "parameter is null";
		}
		String requestType = userAddress.getRequest_type();
		String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
		String clientIP = ConstantUtil.getClientIP(request);
		Log.t("USER_RECORD|IP:"+clientIP
				+"|Account:"+account+"|Action:("+requestType+")"+userAddress.getRequest_url());

		String result = "";
		if(userAddress.getKey() == null || "".equals(userAddress.getKey()) || "123456".equals(userAddress.getKey()))
		{
			userAddress.setKey(ConstantUtil.getAPIConfigKeyInfo(ConstantUtil.ANTI_ADDRESS_CONFIG_INFO_PATH));
		}
		String sign = userRiskService.getAddressAPIConfigSignValue(userAddress);
		if(ConstantUtil.GET_REQUEST.equalsIgnoreCase(requestType))
		{
			sign = sign.replace(" ","");
			userAddress.setSign(MD5Util.getMD5(sign));
			result = userRiskService.getUserAddressByGet(userAddress,account,clientIP);
		}
		else if(ConstantUtil.POST_REQUEST.equalsIgnoreCase(requestType))
		{
			userAddress.setSign(MD5Util.getMD5(sign));
			result = userRiskService.getUserAddressByPost(userAddress,account,clientIP);
		}
		Log.t("USER_API|IP:"+clientIP + "|Account:"+account
				+"|Action:("+requestType+")"+userAddress.getRequest_url()+"|result:"+result);
		return  result;
	}

	@PostMapping("/getUMandMBA")
	public Map<String,String> getUMandMBA(@RequestBody List<UserInfo> userInfoList, HttpServletRequest request)
	{
		if(userInfoList == null ||userInfoList.size() <= 0)
		{
			return null;
		}
		Map<String,String> resultMap = new HashMap<>();
		for(UserInfo userInfo : userInfoList)
		{
			String requestType = userInfo.getRequest_type();
			String account = request.getSession().getAttribute(ConstantUtil.SESSION_KEY).toString();
			String clientIP = ConstantUtil.getClientIP(request);
			String apiType = userInfo.getApiType();
			String apiName="";
			if(userInfo.getKey() == null || "".equals(userInfo.getKey()) || "123456".equals(userInfo.getKey()))
			{
				String configFilePath = "";
				if(ConstantUtil.API_MBA.equalsIgnoreCase(apiType))
				{
					configFilePath = ConstantUtil.MBA_CONFIG_INFO_PATH;
					apiName = ConstantUtil.API_MBA_FULL;
				}
				else if(ConstantUtil.API_UM.equalsIgnoreCase(apiType))
				{
					configFilePath = ConstantUtil.UM_CONFIG_INFO_PATH;
					apiName = ConstantUtil.API_UM_FULL;
				}
				userInfo.setKey(ConstantUtil.getAPIConfigKeyInfo(configFilePath));
			}
			String sign = "datetime="+userInfo.getDatetime()+"&identity="+userInfo.getIdentity()
					+"&name="+userInfo.getName()+"&phone="+userInfo.getPhone()+"&reqid="+userInfo.getReqid()
					+"&service_id="+userInfo.getService_id()+"&sign_type="+userInfo.getSign_type()
					+"&sp_no="+userInfo.getSp_no()+"&key="+userInfo.getKey()+"";
			Log.t("USER_RECORD|IP:"+clientIP
					+"|Account:"+account+"|Action:("+requestType+")("+apiName+")"+userInfo.getRequest_url());

			String result = getApiResponse(userInfo,sign,account,clientIP,apiName);
			resultMap.put(apiType,result);

			Log.t("USER_API|IP:"+clientIP + "|Account:"+account
					+"|Action:("+requestType+")("+apiName+")"+userInfo.getRequest_url()+"|result:"+result);
		}
		return resultMap;
	}

	private String getApiResponse(UserInfo userInfo,String sign,String account,String clientIP,String apiName)
	{
		String result = "";
		String requestType = userInfo.getRequest_type();
		if(ConstantUtil.GET_REQUEST.equalsIgnoreCase(requestType))
		{
			sign = sign.replace(" ","");
			userInfo.setSign(MD5Util.getMD5(sign));
			result = userRiskService.getUserInfoByGet(userInfo,account,clientIP,apiName);
		}
		else if(ConstantUtil.POST_REQUEST.equalsIgnoreCase(requestType))
		{
			userInfo.setSign(MD5Util.getMD5(sign));
			result = userRiskService.getUserInfoByPost(userInfo,account,clientIP,apiName);
		}
		return result;
	}
}