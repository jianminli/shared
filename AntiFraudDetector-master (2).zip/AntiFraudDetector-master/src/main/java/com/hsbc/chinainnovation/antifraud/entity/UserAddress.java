package com.hsbc.chinainnovation.antifraud.entity;

public class UserAddress
{
    private String sp_no;
    private String name;
    private String id_type;
    private String id_no;
    private String phone;
    private String home_city;
    private String home_address;
    private String company_city;
    private String company_address;
    private String bus_shop_city;
    private String bus_shop_address;
    private String recevier_city;
    private String recevier_address;
    private String fix_address;
    private String fix_address_lng;
    private String fix_address_lat;
    private String fix_addr_coorType;
    private String datetime;
    private String reqid;
    private String sign_type;
    private String sign;
    private String request_url;
    private String request_type;
    private String key;

    public String getSp_no() {
        return sp_no;
    }

    public void setSp_no(String sp_no) {
        this.sp_no = sp_no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId_type() {
        return id_type;
    }

    public void setId_type(String id_type) {
        this.id_type = id_type;
    }

    public String getId_no() {
        return id_no;
    }

    public void setId_no(String id_no) {
        this.id_no = id_no;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getHome_city() {
        return home_city;
    }

    public void setHome_city(String home_city) {
        this.home_city = home_city;
    }

    public String getHome_address() {
        return home_address;
    }

    public void setHome_address(String home_address) {
        this.home_address = home_address;
    }

    public String getCompany_city() {
        return company_city;
    }

    public void setCompany_city(String company_city) {
        this.company_city = company_city;
    }

    public String getCompany_address() {
        return company_address;
    }

    public void setCompany_address(String company_address) {
        this.company_address = company_address;
    }

    public String getBus_shop_city() {
        return bus_shop_city;
    }

    public void setBus_shop_city(String bus_shop_city) {
        this.bus_shop_city = bus_shop_city;
    }

    public String getBus_shop_address() {
        return bus_shop_address;
    }

    public void setBus_shop_address(String bus_shop_address) {
        this.bus_shop_address = bus_shop_address;
    }

    public String getRecevier_city() {
        return recevier_city;
    }

    public void setRecevier_city(String recevier_city) {
        this.recevier_city = recevier_city;
    }

    public String getRecevier_address() {
        return recevier_address;
    }

    public void setRecevier_address(String recevier_address) {
        this.recevier_address = recevier_address;
    }

    public String getFix_address() {
        return fix_address;
    }

    public void setFix_address(String fix_address) {
        this.fix_address = fix_address;
    }

    public String getFix_address_lng() {
        return fix_address_lng;
    }

    public void setFix_address_lng(String fix_address_lng) {
        this.fix_address_lng = fix_address_lng;
    }

    public String getFix_address_lat() {
        return fix_address_lat;
    }

    public void setFix_address_lat(String fix_address_lat) {
        this.fix_address_lat = fix_address_lat;
    }

    public String getFix_addr_coorType() {
        return fix_addr_coorType;
    }

    public void setFix_addr_coorType(String fix_addr_coorType) {
        this.fix_addr_coorType = fix_addr_coorType;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getReqid() {
        return reqid;
    }

    public void setReqid(String reqid) {
        this.reqid = reqid;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getRequest_url() {
        return request_url;
    }

    public void setRequest_url(String request_url) {
        this.request_url = request_url;
    }

    public String getRequest_type() {
        return request_type;
    }

    public void setRequest_type(String request_type) {
        this.request_type = request_type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
