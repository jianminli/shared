package com.hsbc.chinainnovation.antifraud.service;

import com.hsbc.chinainnovation.antifraud.util.AESUtil;
import com.hsbc.chinainnovation.antifraud.util.ConstantUtil;
import com.hsbc.chinainnovation.antifraud.util.Log;
import org.springframework.stereotype.Service;
import java.io.*;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.GZIPInputStream;

@Service
public class LoginRegisterService {

    public boolean readUserInfoFromFile(String account,String password,Map<String,String> map)
    {
        String nameAndPassword;
        FileReader fr= null;
        BufferedReader br= null;
        try {
            fr = new FileReader(ConstantUtil.USRE_INFO_PATH);
            br = new BufferedReader(fr);
            while((nameAndPassword=br.readLine()) != null)
            {
                String accountFile = nameAndPassword.substring(0,nameAndPassword.indexOf(":"));
                if(accountFile.equals(account))
                {
                    String passwordFile = nameAndPassword.substring(nameAndPassword.indexOf(":")+1,nameAndPassword.lastIndexOf(":"));
                    if(passwordFile.equals(password))
                    {
                        String flag = nameAndPassword.substring(nameAndPassword.lastIndexOf(":")+1,nameAndPassword.length());
                        if(ConstantUtil.USER_STATUS_YES.equalsIgnoreCase(flag))
                        {
                            map.put("flag","SUCCESS");
                            map.put("message","Login SUCCESS");
                            return  true;
                        }
                        else
                        {
                            map.put("flag","FAIL");
                            map.put("message","This account is not approved");
                            return  false;
                        }
                    }
                    map.put("flag","FAIL");
                    map.put("message","password error");
                    return  false;
                }
            }
        } catch (IOException e) {
            Log.e("get user info fail!",e);
        } finally {
            ConstantUtil.closeIOStream(fr,br);
        }
        map.put("flag","FAIL");
        map.put("message","This account does not exist");
        return false;
    }

    public boolean writeUserInfoToFile(String requestAccountPassword)
    {
        FileWriter fw = null;
        try {
            fw=new FileWriter(ConstantUtil.USRE_INFO_PATH,true);
            fw.write(requestAccountPassword+"\r\n");
            return true;
        } catch (IOException e) {
            Log.e("register user fail!",e);
        } finally {
            try {
                if (fw != null){
                    fw.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    public String checkAccountIsExist(String account)
    {
        FileReader fr= null;
        BufferedReader br= null;
        try {
            fr = new FileReader(ConstantUtil.USRE_INFO_PATH);
            br = new BufferedReader(fr);
            String nameAndPassword;
            while((nameAndPassword=br.readLine()) != null)
            {
               String name = nameAndPassword.substring(0, nameAndPassword.indexOf(":"));
                if(account.equals(name))
                {
                    return nameAndPassword;
                }
            }
        } catch (IOException e) {
            Log.e("Check whether the user exists!",e);
        } finally {
            ConstantUtil.closeIOStream(fr,br);
        }
        return "FAIL";
    }

    public List<Map<String,String>> getAllUserInfo()
    {
        List<Map<String,String>> userInfoList = new ArrayList<>();
        FileReader fr= null;
        BufferedReader br= null;
        try {
            fr = new FileReader(ConstantUtil.USRE_INFO_PATH);
            br = new BufferedReader(fr);
            String userInfo;
            while((userInfo = br.readLine()) != null)
            {
                Map<String,String> map = new HashMap<>();
                map.put("account",userInfo.substring(0,userInfo.indexOf(":")));
                map.put("flag",userInfo.substring(userInfo.lastIndexOf(":")+1,userInfo.length()));
                userInfoList.add(map);
            }
        } catch (IOException e) {
            Log.e("get all user info fail!",e);
        } finally {
            ConstantUtil.closeIOStream(fr,br);
        }
        return userInfoList;
    }

    /**
     * 删除账号，修改密码，修改用户状态
     * 替换文件行内容;
     * 未找到要替换的内容则在末行插入新内容;
     * 若新内容为空，则删除旧内容所在的行
     * */
    public boolean replaceTxtByStr(String oldStr,String replaceStr) {
        String temp;
        File file = new File(ConstantUtil.USRE_INFO_PATH);
        StringBuilder buf = new StringBuilder();
        BufferedReader br = null;
        PrintWriter pw = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            br = new BufferedReader(isr);
            // 保存该行前面的内容
            while((temp = br.readLine()) != null && !temp.equals(oldStr))
            {
                buf.append(temp);
                buf.append(System.getProperty("line.separator"));
            }
            // 将内容插入
            if(replaceStr != null && !"".equals(replaceStr))
            {
                buf.append(replaceStr);
                buf.append(System.getProperty("line.separator"));
            }
            // 保存该行后面的内容
            while ((temp = br.readLine()) != null) {
                buf.append(temp);
                buf.append(System.getProperty("line.separator"));
            }


            FileOutputStream fos = new FileOutputStream(file);
            pw = new PrintWriter(fos);
            pw.write(buf.toString().toCharArray());
        } catch (IOException e) {
            Log.e("update user information fail!",e);
            return false;
        }finally {
            try {
                if(br != null){
                    br.close();
                }
                if(pw != null){
                    pw.flush();
                    pw.close();
                }
            } catch (IOException e) {
                Log.e("stream close error!",e);
            }
        }
        return true;
    }

    /**
     * 获取文件夹下所有的文件名(不带路径)
     * */
    public List<String> getFileName(String dirPath)
    {
        List<String> fileNameList = new ArrayList<>();
        File f = new File(dirPath);
        if (!f.exists())
        {
            Log.w("User information folder does not exist!");
            return null;
         }

        File fa[] = f.listFiles();
        if(fa != null){
            for (File fs : fa)
            {
                if (fs.isFile())
                {
                    fileNameList.add(fs.getName());
                }
            }
        }
        return fileNameList;
    }

    /**
     * 删除文件
     * */
    private boolean deleteFile(String path)
    {
        File file = new File(path);
        // 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
        return (file.exists() && file.isFile()) && file.delete();
    }

    /**
     * copy文件
     * */
    public boolean copyFile(String sourceFilePath,String destFilePath)
    {
        try {
            FileOutputStream out = new FileOutputStream(destFilePath);
            File sourceFile = new File(sourceFilePath);
            Files.copy(sourceFile.toPath(),out);
        } catch (IOException e) {
            Log.e("copy file fail!",e);
            return false;
        }
        return true;
    }

    /**
     * 获取要删除的一个文件名
     * 当备份文件超过fileCount的时候，执行删除动作
     * 当天备份文件>=fileCount/3的时候，删除当天的备份，否则删除时间最老的备份文件
     * */
    public void getWillDeleteFile(List<String> files,String path,int fileCount)
    {
        int dayFileCount = fileCount/3;
        if(files == null || files.size() <= fileCount)
        {
            return;
        }
        Collections.sort(files);
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
        String today = df.format(new Date());
        int todayFileCounts = 0;
        List<String> todayFileList = new ArrayList<>();
        for(String fileName : files)
        {
            if(fileName.contains(today))
            {
                todayFileList.add(fileName);
                todayFileCounts++;
            }
        }
        if(todayFileCounts >= dayFileCount)
        {
            deleteFile(path+todayFileList.get(0));
        }
        else
        {
            deleteFile(path+files.get(0));
        }
    }

    public Map<String,String> getAntiFraudConfigInfo(String path,String antiTab) {
        Map<String, String> map = new HashMap<>();
        map.put("antiTab",antiTab);
        FileReader fr = null;
        BufferedReader br = null;
        try {
            fr = new FileReader(path);
            br = new BufferedReader(fr);
            String configInfo;
            while ((configInfo = br.readLine()) != null) {
                String key = configInfo.substring(0, configInfo.indexOf(":"));
                if("key".equalsIgnoreCase(key))
                {
                    continue;
                }
                String value = configInfo.substring(configInfo.indexOf(":") + 1);
                map.put(key, value);
            }
        } catch (IOException e) {
            Log.e("get API Config info fail!", e);
        } finally {
            ConstantUtil.closeIOStream(fr, br);
        }
        return map;
    }

    public boolean updateAntiFraudConfigInfo(Map<String,Object> reqMap,String path)
    {
        File file = new File(path);
        StringBuilder buf = new StringBuilder();
        PrintWriter pw = null;
        try {
            for (Map.Entry<String,Object> entry : reqMap.entrySet())
            {
                String key = entry.getKey();
                if("antiTab".equalsIgnoreCase(key) || "typeOption".equalsIgnoreCase(key))
                {
                    continue;
                }
                String value = entry.getValue().toString();
                if("key".equalsIgnoreCase(key))
                {
                    value = AESUtil.encrypt(value);
                }else if("Method".equalsIgnoreCase(key))
                {
                    if("GET".equalsIgnoreCase(value))
                        value="GET;POST";
                    else
                        value="POST;GET";
                }
                buf.append(key);
                buf.append(":");
                buf.append(value);
                buf.append(System.getProperty("line.separator"));
            }
            FileOutputStream fos = new FileOutputStream(file);
            pw = new PrintWriter(fos);
            pw.write(buf.toString().toCharArray());
        } catch (IOException e) {
            Log.e("update user information fail!",e);
            return false;
        }finally {
            if(pw != null){
                pw.flush();
                pw.close();
            }
        }
        return true;
    }

    public List<Map<String,String>> getAllUserLogInfo()
    {
        List<String> fileNameList = checkFileName(getFileName(ConstantUtil.USER_RECORD_LOG_DIR_PATH));
        List<String> filePathList = unGzipFile(fileNameList);
        Collections.sort(filePathList);
        filePathList.add(ConstantUtil.USER_RECORD_LOG_PATH);
        List<Map<String,String>> userLogInfoList = new ArrayList<>();
        FileReader fr= null;
        BufferedReader br= null;
        for(String filePath : filePathList)
        {
            try {
                fr = new FileReader(filePath);
                br = new BufferedReader(fr);
                String logInfo;
                while((logInfo = br.readLine()) != null)
                {
                    Map<String,String> map = new HashMap<>();
                    String[] logList = logInfo.split("\\|");
                    map.put("time",logList[0].substring(0,logList[0].indexOf(" -")));
                    map.put("IP",logList[1].substring(logList[1].indexOf(":")+1,logList[1].indexOf("[")));
                    map.put("hostName",logList[1].substring(logList[1].lastIndexOf(":")+1,logList[1].indexOf("]")));
                    map.put("account",logList[2].substring(logList[2].indexOf(":")+1));
                    map.put("action",logList[3].substring(logList[3].indexOf(":")+1));
                    map.put("result","");
                    if(logList.length > 4){
                        map.put("result",logList[4].substring(logList[4].indexOf(":")+1));
                    }
                    userLogInfoList.add(map);
                }
            } catch (IOException e) {
                Log.e("get all Log info fail!",e);
            } finally {
                ConstantUtil.closeIOStream(fr,br);
            }
            if(filePath.contains("-"))
                deleteFile(filePath);
        }
        List<Map<String,String>> sortFilePathList = new ArrayList<>();
        for(int i = userLogInfoList.size()-1;i>=0;i--)
        {
            sortFilePathList.add(userLogInfoList.get(i));
        }
        return sortFilePathList;
    }
    private List<String> checkFileName(List<String> fileNameList)
    {
        List<String> newFileNameList = new ArrayList<>();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, -6);
        date = calendar.getTime();
        String weekDay = df.format(date);
        for(String fileName : fileNameList)
        {
            if(!fileName.endsWith(".log.gz"))
                continue;
            String fileNameDate = fileName.substring(fileName.indexOf("-")+1,fileName.lastIndexOf("-"));
            try {
                Date fileDate = df.parse(fileNameDate);
                Date weekDate = df.parse(weekDay);
                if(fileDate.getTime() >= weekDate.getTime())
                {
                    newFileNameList.add(fileName);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return newFileNameList;
    }
    private List<String> unGzipFile(List<String> fileNameList)
    {
        List<String> newFileNameList = new ArrayList<>();
        FileInputStream fin = null;
        GZIPInputStream gzin = null;
        FileOutputStream fout = null;
        for (String fileName : fileNameList)
        {
            String sourcedir = ConstantUtil.USER_RECORD_LOG_DIR_PATH+fileName;
            String ouputfile = "";
            try {
                //建立gzip压缩文件输入流
                fin = new FileInputStream(sourcedir);
                //建立gzip解压工作流
                gzin = new GZIPInputStream(fin);
                //建立解压文件输出流
                ouputfile = sourcedir.substring(0,sourcedir.lastIndexOf('.'));
                fout = new FileOutputStream(ouputfile);

                int num;
                byte[] buf=new byte[1024];

                while ((num = gzin.read(buf,0,buf.length)) != -1)
                {
                    fout.write(buf,0,num);
                }

            } catch (Exception ex){
                System.err.println(ex.toString());
            }finally {
                try {
                    if(fin !=null)
                        fin.close();
                    if(fout !=null)
                        fout.close();
                    if(gzin !=null)
                        gzin.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            newFileNameList.add(ouputfile);
        }
        return newFileNameList;
    }
}