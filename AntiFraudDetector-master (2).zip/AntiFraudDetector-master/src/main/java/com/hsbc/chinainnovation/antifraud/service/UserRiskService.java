package com.hsbc.chinainnovation.antifraud.service;

import com.hsbc.chinainnovation.antifraud.entity.UserAddress;
import com.hsbc.chinainnovation.antifraud.entity.UserInfo;
import com.hsbc.chinainnovation.antifraud.util.ConstantUtil;
import com.hsbc.chinainnovation.antifraud.util.Log;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.springframework.stereotype.Service;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.URLDecoder;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class UserRiskService {

    public String getUserInfoByGet(UserInfo userInfo,String account,String clientIP,String apiName)
    {
        String sp_no = userInfo.getSp_no() == null ? "" : userInfo.getSp_no();
        String service_id = userInfo.getService_id() == null ? "" : userInfo.getService_id();
        String reqid = userInfo.getReqid() == null ? "" : userInfo.getReqid();
        String name = userInfo.getName() == null ? "" : userInfo.getName();
        String identity = userInfo.getIdentity() == null ? "" : userInfo.getIdentity();
        String phone = userInfo.getPhone() == null ? "" : userInfo.getPhone();
        String datetime = userInfo.getDatetime() == null ? "" : userInfo.getDatetime();
        String sign_type = userInfo.getSign_type() == null ? "" : userInfo.getSign_type();
        String sign = userInfo.getSign() == null ? "" : userInfo.getSign();

        String parameter = "sp_no="+sp_no+"&service_id="+service_id+"&reqid="+reqid
                        +"&name="+name+"&identity="+identity+"&phone="+phone
                        +"&datetime="+datetime+"&sign_type="+sign_type+"&sign="+sign;
        String request_url = userInfo.getRequest_url()+"?"+parameter;
        Log.t("USER_API|IP:"+clientIP + "|Account:"+account+"|Action:(GET)("+apiName+")"+request_url);

        return requstHttpClientGet(request_url);
    }

    public String getUserInfoByPost(UserInfo userInfo,String account,String clientIP,String apiName)
    {
        List<NameValuePair> params = new ArrayList<>();
        if(null != userInfo.getSp_no() && !"".equals(userInfo.getSp_no()))
        {
            params.add(new BasicNameValuePair("sp_no", userInfo.getSp_no()));
        }
        if(null != userInfo.getService_id() && !"".equals(userInfo.getService_id()))
        {
            params.add(new BasicNameValuePair("service_id", userInfo.getService_id()));
        }
        if(null != userInfo.getReqid() && !"".equals(userInfo.getReqid()))
        {
            params.add(new BasicNameValuePair("reqid", userInfo.getReqid()));
        }
        if(null != userInfo.getName() && !"".equals(userInfo.getName()))
        {
            params.add(new BasicNameValuePair("name", userInfo.getName()));
        }
        if(null != userInfo.getIdentity() && !"".equals(userInfo.getIdentity()))
        {
            params.add(new BasicNameValuePair("identity", userInfo.getIdentity()));
        }
        if(null != userInfo.getPhone() && !"".equals(userInfo.getPhone()))
        {
            params.add(new BasicNameValuePair("phone", userInfo.getPhone()));
        }
        if(null != userInfo.getDatetime() && !"".equals(userInfo.getDatetime()))
        {
            params.add(new BasicNameValuePair("datetime", userInfo.getDatetime()));
        }
        if(null != userInfo.getSign_type() && !"".equals(userInfo.getSign_type()))
        {
            params.add(new BasicNameValuePair("sign_type", userInfo.getSign_type()));
        }
        if(null != userInfo.getSign() && !"".equals(userInfo.getSign()))
        {
            params.add(new BasicNameValuePair("sign", userInfo.getSign()));
        }
        String requestUrl = userInfo.getRequest_url();

        Log.t("USER_API|IP:"+clientIP + "|Account:"+account+"|Action:(POST)("+apiName+")"+requestUrl+";Params:"+params);
        return requestHttpClientPost(requestUrl,params);
    }

    public String getUserAddressByGet(UserAddress userAddress,String account,String clientIP)
    {
        String sp_no = userAddress.getSp_no() == null ? "" : userAddress.getSp_no();
        String name = userAddress.getName() == null ? "" : userAddress.getName();
        String id_type = userAddress.getId_type() == null ? "" : userAddress.getId_type();
        String id_no = userAddress.getId_no() == null ? "" : userAddress.getId_no();
        String phone = userAddress.getPhone() == null ? "" : userAddress.getPhone();
        StringBuilder personAddress = new StringBuilder();
        if(null != userAddress.getHome_city() && !"".equals(userAddress.getHome_city())
                && null != userAddress.getHome_address() && !"".equals(userAddress.getHome_address()))
        {
            personAddress.append("&home_city="+userAddress.getHome_city()+"&home_address="+userAddress.getHome_address());
        }
        if(null != userAddress.getCompany_city() && !"".equals(userAddress.getCompany_city())
                && null != userAddress.getCompany_address() && !"".equals(userAddress.getCompany_address()))
        {
            personAddress.append("&company_city="+userAddress.getCompany_city()+"&company_address="+userAddress.getCompany_address());
        }
        if(null != userAddress.getBus_shop_city() && !"".equals(userAddress.getBus_shop_city())
                && null != userAddress.getBus_shop_address() && !"".equals(userAddress.getBus_shop_address()))
        {
            personAddress.append("&bus_shop_city="+userAddress.getBus_shop_city()+"&bus_shop_address="+userAddress.getBus_shop_address());
        }
        if(null != userAddress.getRecevier_city() && !"".equals(userAddress.getRecevier_city())
                && null != userAddress.getRecevier_address() && !"".equals(userAddress.getRecevier_address()))
        {
            personAddress.append("&recevier_city="+userAddress.getRecevier_city()+"&recevier_address="+userAddress.getRecevier_address());
        }
        StringBuilder fixAddress = new StringBuilder();
        if(null != userAddress.getFix_address() && !"".equals(userAddress.getFix_address()))
        {
            fixAddress.append("&fix_address="+userAddress.getFix_address());
        }
        if(null != userAddress.getFix_address_lng() && !"".equals(userAddress.getFix_address_lng()))
        {
            fixAddress.append("&fix_address_lng="+userAddress.getFix_address_lng());
        }
        if(null != userAddress.getFix_address_lat() && !"".equals(userAddress.getFix_address_lat()))
        {
            fixAddress.append("&fix_address_lat="+userAddress.getFix_address_lat());
        }
        if(null != userAddress.getFix_addr_coorType() && !"".equals(userAddress.getFix_addr_coorType()))
        {
            fixAddress.append("&fix_addr_coorTpey="+userAddress.getFix_addr_coorType());
        }
        String datetime = userAddress.getDatetime() == null ? "" : userAddress.getDatetime();
        String reqid = userAddress.getReqid() == null ? "" : userAddress.getReqid();
        String sign_type = userAddress.getSign_type() == null ? "" : userAddress.getSign_type();
        String sign = userAddress.getSign() == null ? "" : userAddress.getSign();

        String parameter = "sp_no="+sp_no+"&name="+name+"&id_type="+id_type
                +"&id_no="+id_no+"&phone="+phone+personAddress.toString()+fixAddress.toString()
                +"&datetime="+datetime+"&reqid="+reqid+"&sign_type="+sign_type+"&sign="+sign;
        String request_url = userAddress.getRequest_url()+"?"+parameter;

        Log.t("USER_API|IP:"+clientIP + "|Account:"+account+"|Action:(GET)"+request_url);
        return requstHttpClientGet(request_url);
    }

    public String getUserAddressByPost(UserAddress userAddress,String account,String clientIP)
    {
        List<NameValuePair> params = new ArrayList<>();
        if(null != userAddress.getSp_no() && !"".equals(userAddress.getSp_no()))
        {
            params.add(new BasicNameValuePair("sp_no", userAddress.getSp_no()));
        }
        if(null != userAddress.getName() && !"".equals(userAddress.getName()))
        {
            params.add(new BasicNameValuePair("name", userAddress.getName()));
        }
        if(null != userAddress.getId_type() && !"".equals(userAddress.getId_type()))
        {
            params.add(new BasicNameValuePair("id_type", userAddress.getId_type()));
        }
        if(null != userAddress.getId_no() && !"".equals(userAddress.getId_no()))
        {
            params.add(new BasicNameValuePair("id_no", userAddress.getId_no()));
        }
        if(null != userAddress.getPhone() && !"".equals(userAddress.getPhone()))
        {
            params.add(new BasicNameValuePair("phone", userAddress.getPhone()));
        }
        if(null != userAddress.getHome_city() && !"".equals(userAddress.getHome_city())
                && null != userAddress.getHome_address() && !"".equals(userAddress.getHome_address()))
        {
            params.add(new BasicNameValuePair("home_city", userAddress.getHome_city()));
            params.add(new BasicNameValuePair("home_address", userAddress.getHome_address()));
        }
        if(null != userAddress.getCompany_city() && !"".equals(userAddress.getCompany_city())
                && null != userAddress.getCompany_address() && !"".equals(userAddress.getCompany_address()))
        {
            params.add(new BasicNameValuePair("company_city", userAddress.getCompany_city()));
            params.add(new BasicNameValuePair("company_address", userAddress.getCompany_address()));
        }
        if(null != userAddress.getBus_shop_city() && !"".equals(userAddress.getBus_shop_city())
                && null != userAddress.getBus_shop_address() && !"".equals(userAddress.getBus_shop_address()))
        {
            params.add(new BasicNameValuePair("bus_shop_city", userAddress.getBus_shop_city()));
            params.add(new BasicNameValuePair("bus_shop_address", userAddress.getBus_shop_address()));
        }
        if(null != userAddress.getRecevier_city() && !"".equals(userAddress.getRecevier_city())
                && null != userAddress.getRecevier_address() && !"".equals(userAddress.getRecevier_address()))
        {
            params.add(new BasicNameValuePair("recevier_city", userAddress.getRecevier_city()));
            params.add(new BasicNameValuePair("recevier_address", userAddress.getRecevier_address()));
        }
        if(null != userAddress.getFix_address() && !"".equals(userAddress.getFix_address()))
        {
            params.add(new BasicNameValuePair("fix_address", userAddress.getFix_address()));
        }
        if(null != userAddress.getFix_address_lng() && !"".equals(userAddress.getFix_address_lng()))
        {
            params.add(new BasicNameValuePair("fix_address_lng", userAddress.getFix_address_lng()));
        }
        if(null != userAddress.getFix_address_lat() && !"".equals(userAddress.getFix_address_lat()))
        {
            params.add(new BasicNameValuePair("fix_address_lat", userAddress.getFix_address_lat()));
        }
        if(null != userAddress.getFix_addr_coorType() && !"".equals(userAddress.getFix_addr_coorType()))
        {
            params.add(new BasicNameValuePair("fix_addr_coorType", userAddress.getFix_addr_coorType()));
        }
        if(null != userAddress.getDatetime() && !"".equals(userAddress.getDatetime()))
        {
            params.add(new BasicNameValuePair("datetime", userAddress.getDatetime()));
        }
        if(null != userAddress.getReqid() && !"".equals(userAddress.getReqid()))
        {
            params.add(new BasicNameValuePair("reqid", userAddress.getReqid()));
        }
        if(null != userAddress.getSign_type() && !"".equals(userAddress.getSign_type()))
        {
            params.add(new BasicNameValuePair("sign_type", userAddress.getSign_type()));
        }
        if(null != userAddress.getSign() && !"".equals(userAddress.getSign()))
        {
            params.add(new BasicNameValuePair("sign", userAddress.getSign()));
        }
        String requestUrl = userAddress.getRequest_url();
        Log.t("USER_API|IP:"+clientIP + "|Account:"+account+"|Action:(POST)"+requestUrl+";Params:"+params);
        return requestHttpClientPost(requestUrl,params);
    }

    public String getUserLogInfo(String path)
    {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");//设置日期格式
        StringBuilder sb = new StringBuilder(path);
        sb.insert(path.indexOf("-")+1,df.format(new Date()));
        return requstElkDataPost(sb.toString());
    }

    private String requstHttpClientGet(String requestUrl)
    {
        requestUrl = requestUrl.replace(" ","");
        String result;
//        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpClient httpClient = getHttpclient();
        CloseableHttpResponse httpResponse  = null;
        try {
            HttpGet httpGet = new HttpGet(URLDecoder.decode(requestUrl,"UTF-8"));
            httpResponse = httpClient.execute(httpGet);
            result = checkOutResponse(httpResponse.getEntity().getContent());
        } catch (Exception e) {
            result = e.toString();
            Log.e("request API fail by get!",e);
        }finally {
            closeIOStream(httpResponse,httpClient);
        }
        return result;
    }

    private String requestHttpClientPost(String requestUrl,List<NameValuePair> params)
    {
        String result;
        CloseableHttpResponse httpResponse = null;
//        RequestConfig defaultRequestConfig = RequestConfig.custom()
//            .setSocketTimeout(5000)
//            .setConnectTimeout(5000)
//            .setConnectionRequestTimeout(5000)
//            .build();
//        CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
        CloseableHttpClient httpClient = getHttpclient();

        try {
            HttpPost httpPost = new HttpPost(requestUrl);
            httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
            httpResponse = httpClient.execute(httpPost);
            result = checkOutResponse(httpResponse.getEntity().getContent());
        } catch (Exception e) {
            result = e.getMessage();
            Log.e("request API fail by post!",e);
        }finally {
            closeIOStream(httpResponse,httpClient);
        }
        return result;
    }

    private String requstElkDataPost(String requestUrl)
    {
        String params = "{\n" +
                "  \"query\": { \"match_all\": {} },\n" +
                "  \"_source\": [\"time\",\"ip\",\"HostName\", \"Account\",\"Action\",\"result\"],\n" +
                "  \"sort\": { \"time\": { \"order\": \"desc\" } }\n" +
                "}";
        String result;
        CloseableHttpResponse httpResponse = null;
        RequestConfig defaultRequestConfig = RequestConfig.custom()
            .setSocketTimeout(5000)
            .setConnectTimeout(5000)
            .setConnectionRequestTimeout(5000)
            .build();
        CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();

        try {
            StringEntity s = new StringEntity(params);
            s.setContentEncoding("UTF-8");
            s.setContentType("application/json");//发送json数据需要设置contentType
            HttpPost httpPost = new HttpPost(requestUrl);
            httpPost.setEntity(s);
            httpResponse = httpClient.execute(httpPost);
            result = checkOutResponse(httpResponse.getEntity().getContent());
        } catch (Exception e) {
            result = e.getMessage();
            Log.e("request API fail by post!",e);
        }finally {
            closeIOStream(httpResponse,httpClient);
        }
        return result;
    }
    private CloseableHttpClient getHttpclient()
    {
        CloseableHttpClient httpclient = null;
        InputStream instream = null;
        try {
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            instream = new FileInputStream(new File(ConstantUtil.CLIENT_KEYSTORE_PATH));

            keyStore.load(instream, ConstantUtil.CLIENT_KEYSTORE_PASSWORD.toCharArray());


            SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, ConstantUtil.CLIENT_KEYSTORE_PASSWORD.toCharArray()).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext
                    , new String[] {"TLSv1"}
                    , null
                    , SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (Exception e) {
            Log.e("create CloseableHttpClient object fail!",e);
        } finally {
            try {
                if(instream != null){
                    instream.close();
                }
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
        return httpclient;
    }

    private String checkOutResponse(InputStream in)
    {
        BufferedReader reader = null;
        StringBuilder sb = new StringBuilder();
        try
        {
            reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null)
            {
                sb.append(line);
            }
        } catch (IOException e) {
            Log.e("Failed to convert the information returned by API!",e);
        }
        finally{
            ConstantUtil.closeIOStream(in,reader);
        }
        return sb.toString();
    }
    private void closeIOStream(CloseableHttpResponse httpResponse,CloseableHttpClient httpClient)
    {
        try {
            if(httpResponse != null)
            {
                httpResponse.close();
            }
            if(httpClient != null)
            {
                httpClient.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getAddressAPIConfigSignValue(UserAddress user)
    {
        String sign = "";
        if(user.getCompany_address() != null && !"".equals(user.getCompany_address())
                && user.getCompany_city() != null && !"".equals(user.getCompany_city())
                && user.getHome_address() != null && !"".equals(user.getHome_address())
                && user.getHome_city() != null && !"".equals(user.getHome_city()))
        {
            sign = "company_address="+user.getCompany_address()+"&company_city="+user.getCompany_city()
                    +"&datetime="+user.getDatetime()+"&home_address="+user.getHome_address()
                    +"&home_city="+user.getHome_city()+"&id_no="+user.getId_no()+"&id_type="+user.getId_type()
                    +"&name="+user.getName()+"&phone="+user.getPhone()+"&reqid="+user.getReqid()
                    +"&sign_type="+user.getSign_type()+"&sp_no="+user.getSp_no()+"&key="+user.getKey()+"";
        }
        else if(user.getCompany_address() != null && !"".equals(user.getCompany_address())
                && user.getCompany_city() != null && !"".equals(user.getCompany_city()))
        {
            sign = "company_address="+user.getCompany_address()+"&company_city="+user.getCompany_city()
                    +"&datetime="+user.getDatetime()+"&id_no="+user.getId_no()+"&id_type="+user.getId_type()
                    +"&name="+user.getName()+"&phone="+user.getPhone()+"&reqid="+user.getReqid()
                    +"&sign_type="+user.getSign_type()+"&sp_no="+user.getSp_no()+"&key="+user.getKey()+"";
        }else if(user.getHome_address() != null && !"".equals(user.getHome_address())
                && user.getHome_city() != null && !"".equals(user.getHome_city()))
        {
            sign = "datetime="+user.getDatetime()+"&home_address="+user.getHome_address()
                    +"&home_city="+user.getHome_city()+"&id_no="+user.getId_no()+"&id_type="+user.getId_type()
                    +"&name="+user.getName()+"&phone="+user.getPhone()+"&reqid="+user.getReqid()
                    +"&sign_type="+user.getSign_type()+"&sp_no="+user.getSp_no()+"&key="+user.getKey()+"";
        }
        return sign;
    }
}
