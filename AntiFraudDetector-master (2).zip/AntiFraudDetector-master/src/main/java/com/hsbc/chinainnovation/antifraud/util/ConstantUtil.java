package com.hsbc.chinainnovation.antifraud.util;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConstantUtil {

//    String url = "https://jrws.baidu.com/risk/api/info/search";
//    String url = "https://jrws.baidu.com/risk/api/info/check/address";
    //密钥
//    public static final String CLIENT_KEYSTORE_PATH  = "D:/projects/AntiFraudDetector/antifraud/keystore.p12";
    public static final String CLIENT_KEYSTORE_PATH  = "C:/products/AntiFraudDetector/antifraud/keystore.p12";

    public final static String CLIENT_KEYSTORE_PASSWORD = "123456"; //客户端证书密码及密钥库密码

    //日志请求路径
//    public static final String USER_RECORD_LOG_PATH = "D:/projects/antifraud/logs/userActionRecord/userActionRecord.log";
//    public static final String USER_RECORD_LOG_DIR_PATH = "D:/projects/antifraud/logs/userActionRecord/";
    public static final String USER_RECORD_LOG_PATH = "C:/logs/userActionRecord/userActionRecord.log";
    public static final String USER_RECORD_LOG_DIR_PATH = "C:/logs/userActionRecord/";


    //接口请求方式
    public static final String POST_REQUEST = "POST";
    public static final String GET_REQUEST = "GET";
    //本地用户信息文件路径
//    public static final String USRE_INFO_PATH = "D:/projects/AntiFraudDetector/antifraud/userInfos/userInfo.txt";
//    public static final String USRE_INFOS_PATH = "D:/projects/AntiFraudDetector/antifraud/userInfos/";
    public static final String USRE_INFO_PATH = "C:/products/AntiFraudDetector/antifraud/userInfos/userInfo.txt";
    public static final String USRE_INFOS_PATH = "C:/products/AntiFraudDetector/antifraud/userInfos/";

    public static final String ANTI_FRAUD_CONFIG_INFO_PATH = "C:/products/AntiFraudDetector/antifraud/userConfig/AntiFraudConfigInfo.txt";
    public static final String ANTI_ADDRESS_CONFIG_INFO_PATH = "C:/products/AntiFraudDetector/antifraud/userConfig/AntiAddressConfigInfo.txt";
    public static final String UM_CONFIG_INFO_PATH = "C:/products/AntiFraudDetector/antifraud/userConfig/UMConfigInfo.txt";
    public static final String MBA_CONFIG_INFO_PATH = "C:/products/AntiFraudDetector/antifraud/userConfig/MBAConfigInfo.txt";
    public static final String ANTI_CONFIG_INFOS_PATH = "C:/products/AntiFraudDetector/antifraud/userConfig/";
//    public static final String ANTI_FRAUD_CONFIG_INFO_PATH = "/opt/AntiFraudDetector/antifraud/userConfig/AntiFraudConfigInfo.txt";
//    public static final String ANTI_ADDRESS_CONFIG_INFO_PATH = "/opt/AntiFraudDetector/antifraud/userConfig/AntiAddressConfigInfo.txt";
//    public static final String UM_CONFIG_INFO_PATH = "/opt/AntiFraudDetector/antifraud/userConfig/UMConfigInfo.txt";
//    public static final String MBA_CONFIG_INFO_PATH = "/opt/AntiFraudDetector/antifraud/userConfig/MBAConfigInfo.txt";
//    public static final String ANTI_CONFIG_INFOS_PATH = "/opt/AntiFraudDetector/antifraud/userConfig/";

    //登录session key
    public final static String SESSION_KEY = "user";
    //用户状态，yes表示正常，no表示未审批不能登录使用
    public final static String USER_STATUS_YES = "YES";
    public final static String USER_STATUS_NO = "NO";
    //用户信息备份文件保存个数
    public final static int USER_BACKUP_FILE_10 = 10;
    public final static int USER_BACKUP_FILE_100 = 100;
    //多头和黑产接口
    public final static String API_UM = "UM";//黑产
    public final static String API_MBA = "MBA";//多头
    public final static String API_UM_FULL = "black agent";//黑产
    public final static String API_MBA_FULL = "concentration risk";//多头
    public final static String API_FRAUD_FULL = "Anti Fraud";//风险名单

    public static String getClientIP(HttpServletRequest request)
    {
        String ipAddress = request.getHeader("x-forwarded-for");

        if(ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress))
        {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }

        if(ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress))
        {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }

        if(ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress))
        {
            ipAddress = request.getRemoteAddr();

            if(ipAddress.equals("127.0.0.1") || ipAddress.equals("0:0:0:0:0:0:0:1"))
            {
                //根据网卡取本机配置的IP
                InetAddress inet;
                try {
                    inet = InetAddress.getLocalHost();
                    ipAddress= inet.getHostAddress();
                } catch (UnknownHostException e) {
                    Log.e("get client IP error!",e);
                }
            }
        }

        //对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割  "***.***.***.***".length() = 15
        if(ipAddress!=null && ipAddress.length()>15)
        {
            if(ipAddress.indexOf(",")>0)
            {
                ipAddress = ipAddress.substring(0,ipAddress.indexOf(","));
            }
        }
        String hostName = "";
        try {
            DNSLookupThread dnsTh = new DNSLookupThread(ipAddress);
            dnsTh.start();
            dnsTh.join(1000);
            hostName = dnsTh.getHostName();

        } catch (Exception e) {
            Log.e("get client HostName error!",e);
        }
        return ipAddress+"[HostName:"+hostName+"]";
    }
    /**
     * unicode 转字符串
     */
    public static String unicode2String(String unicode) {

        StringBuilder string = new StringBuilder();

        String[] hex = unicode.split("\\\\u");

        for (int i = 1; i < hex.length; i++) {

            // 转换出每一个代码点
            int data = Integer.parseInt(hex[i], 16);

            // 追加成string
            string.append((char) data);
        }
        return string.toString();
    }
    public static void closeIOStream(Closeable fr, Closeable br)
    {
        try {
            if(fr != null){
                fr.close();
            }
            if(br != null){
                br.close();
            }
        } catch (IOException e) {
            Log.e("stream close error!",e);
        }
    }
    public static String getNowTime ()
    {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        return df.format(new Date());
    }

    public static String getAPIConfigKeyInfo(String filePath)
    {
        String keyValue;
        FileReader fr = null;
        BufferedReader br = null;
        try {
            fr = new FileReader(filePath);
            br = new BufferedReader(fr);
            String configInfo;
            while ((configInfo = br.readLine()) != null) {
                String key = configInfo.substring(0, configInfo.indexOf(":"));
                if("key".equalsIgnoreCase(key))
                {
                    String value = configInfo.substring(configInfo.indexOf(":") + 1);
                    if(!"".equals(value))
                    {
                        byte[] byteValue = AESUtil.decrypt(value);
                        if(byteValue != null)
                        {
                            keyValue = new String(byteValue);
                            return keyValue;
                        }
                    }
                }
            }
        } catch (IOException e) {
            Log.e("get API Config info fail!", e);
        } finally {
            ConstantUtil.closeIOStream(fr, br);
        }
        return null;
    }
}
