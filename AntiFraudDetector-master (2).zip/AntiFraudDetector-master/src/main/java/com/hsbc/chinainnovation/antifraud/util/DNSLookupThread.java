package com.hsbc.chinainnovation.antifraud.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
/**
 * 虽然Socket类有setTimeout()方法，URLConnection有setConnectTimeout()方法，
 * 但这都不能给DNS查询过程添加时间限制，也就是说，如果DNS服务器挂了，
 * 那么代码就会阻塞几十秒才能抛出异常。
 * 以下代码的效果相当于给DNS查询添加了一个2秒的超时时间限制（调用时设置时间）。
 * 简单分析一下是如何做到的：
 * DNS线程执行InetAddress.getByName(ip).getHostName()方法向DNS发起查询请求，
 * 此时因为网络IO，DNS线程会阻塞，但是由于主线程调用了join，所以主线程不会继续执行。这时会出现２种情况：
 * 1. 网络IO完成，DNS线程继续执行，getByName()方法返回，将包含了目标主机IP的InetAddress对象保存到成员变量中。
 * 2. 网络IO未完成，但是2秒已过，主线程的join()调用返回，主线程继续执行，但是getIP()会返回null，即表示DNS查询失败。
 * 如此一来完美解决了DNS查询超时问题。
 * */
public class DNSLookupThread extends Thread {
    private String hostname;
    private String ip;

    public DNSLookupThread(String ip) {
        this.ip = ip;
    }

    public void run() {
        try {
            set(InetAddress.getByName(ip).getHostName());
        } catch (UnknownHostException e) {
        }
    }

    private synchronized void set(String hostname) {
        this.hostname = hostname;
    }

    public synchronized String getHostName() {
        if (null != this.hostname) {
            return hostname;
        }
        return ip;
    }
}