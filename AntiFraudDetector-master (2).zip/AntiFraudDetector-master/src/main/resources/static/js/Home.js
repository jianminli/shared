/*axios.defaults.headers.post['Content-Type'] = 'application/json';
	 var http = axios.create({
	 baseURL: 'http://localhost:8080',
	 headers: {'X-Requested-With': 'XMLHttpRequest'}
	 });*/
	 var describe={"7d":"0-7天","15d":"8-15天","30d":"16-30天","3m":"31-90天","6m":"91-180天","12m":"181-365天",">12m":"365天以上"}
	 var header = {
                  'Content-Type': 'application/json;charset=UTF-8',
                  'cache-control': 'no-cache',
                  'x-requested-with': ' XMLHttpRequest'
     }
     Vue.component("tabPane",{
         template:"#demo",
         data:function(){
             return {
                 cofig:[]
             }
         },
         props:["cofig"]
     })
      Vue.filter( 'capitalize_line' , function(str) {
            var array = str.toLowerCase().split(" ");
            for (var i = 0; i < array.length; i++){
                array[i] = array[i][0].toUpperCase() + array[i].substring(1, array[i].length);
            }
            var string = array.join(" ").replace(/_/g, " ");
            return string;
       });
     $("body").click(function(e){
              console.log(e.target.id === 'toggler-btn')
              if(e.target.id === 'toggler-btn'){
                    vm.isShowDetail = true;
              }else {
                    vm.isShowDetail = false;
              }
     })
     function detail(data){
        console.log(data)
       vm.isShowDetail = true;
        $("#detail").empty();
        if(!data){
            var html="<div><p class=\"row\" >No detail</div>";
            $("#detail").append(html);
            return;
        }
        var dataJson = data;

        var a = dataJson["query_org_cnt"];
                                      var arr = [];
                                      for(var key in a ){
                                           var map = {};
                                           map[key] = a[key];
                                           arr.push(map)
                                      }

                                          for(var key in dataJson){
                                              if(key =="query_org_types"){
                                                    var html="<div><p class=\"dutyLabel\" >Mloan details</p><div class=\"dutyValue\">"
                                                    for(var i=0;i<dataJson["query_org_types"].length;i++){
                                                            if(JSON.stringify(arr[i])){
                                                                for(var subKey in arr[i]){
                                                                       html +="<p>"+describe[subKey] +"在"+dataJson["query_org_types"][i]+"上查询了" +arr[i][subKey]+"次；</p>"
                                                                }
                                                           }else{
                                                                html +="<p>没有在"+dataJson["query_org_types"][i]+"查询过；</p>"
                                                            }

                                                    }
                                                    html += "</div></div>";
                                                   $("#detail").append(html);
                                              }

                                          }


     }
	var vm = new Vue({
		el: '#app',
		data:{
			ApiUrl:"",
			isLoading:false,
			user:"",
			isScaling:false,
			isShowDetail:false,
			isTrue:true,
			isFalse:false,
			cur:0,
			APIShow:{
			    "Anti-fraud Detection":true,
			    "Address Validation":true
			},
			vueClass:{
				isActive:true,
			},
			res: {
				id:"",
				header:"",
				addressH:"",
				addressC:"",
				blackDetails:"",
				blackReason:"",
				blackLevel:"",
				homeAddress:"",
				companyAddress:"",
				Ant:"",
				UM:"",
				MBA:"",
				body:[]
			},
			api: {
				id:0,
				name:"",
				selecturl:"",
				type:"",
				header:"",
				config:{
					configShow:"",
					isShow:"",
					isClosed:""
				},
				textShow:{
					isShow:"",
					isClosed:"",
					textShow:""
				},
				body:""
			},
			commomData:{
                "Name": "",
                "ID number": "",
                "Phone number": "",
                "Home city":"",
                "Home address":"",
                "Company city":"",
                "Company address":""
			},
			api_address:{
				id:2,
				dropdownShow:false,
				config:{
					configShow:false,
					isShow:true,
					isClosed:false
				},
				textShow:{
					isShow:true,
					isClosed:false,
					textShow:false
				},
				name:"Address Validation",
				body:[]
			},
            api_whole:{
                   id:1,
                   dropdownShow:false,
                   config:{
                          configShow:false,
                          isShow:true,
                          isClosed:false
                   },
                   textShow:{
                          isShow:true,
                          isClosed:false,
                          textShow:false
                   },
                   name:"Anti-fraud Detection",
                   body:[]
            }
		},
		created:function(){
			this.ApiUrls();
			this.APIConfig();
		},
		methods: {
			APIConfig:function(){
				axios.get(this.ApiUrl+"/getAntiFraudConfigInfo.do",{headers:header})
				     .then(function(res){
						vm.sessionTimeOut(res);
						vm.user = decodeURIComponent(res.headers.loginusername);
                        /*********whole*******/
                        var bodyList = [];
                        for(var i=0,len=res.data.length;i<len;i++){
                             var typeList = res.data[i].Method.split(";")
                             var typeOption = [];
                             for(var key in typeList){
                                  typeOption.push({type:typeList[key]})
                             }
                             var bodyObject = {};
                             if(res.data[i].isShow=="true"){
                                  bodyObject.isShow=true
                             }else{
                                  bodyObject.isShow=false
                             }
                             bodyObject.url=res.data[i].url;
                             bodyObject.Method=typeList[0];
                             bodyObject.typeOption=typeOption;
                             bodyObject.antiTab=res.data[i].antiTab;
                             bodyObject.sp_no=res.data[i].sp_no;
                             bodyObject.reqid=res.data[i].reqid;
                             bodyObject.datetime=res.data[i].datetime;
                             bodyObject.sign_type=res.data[i].sign_type;
                             bodyObject.key="123456";
                             if(res.data[i].antiTab=="AntiAdress"){
                                  bodyObject.id_type=res.data[i].id_type
                             }else{
                                  bodyObject.service_id=res.data[i].service_id
                             }
                             if(res.data[i].isShow=="false"){
                                  vm.APIShow["anti-fraud detection"]=false;
                             }
                             if(res.data[i].isShow=="false"){
                                  vm.APIShow["Address Validation"]=false;
                             }
                             bodyList.push(bodyObject)
                        }
                        vm.api_address.body = bodyList
                        vm.api_whole.body = bodyList
                        if(!vm.APIShow["anti-fraud detection"]){
                              vm.cur = 1;
                              vm.showApiDetail(2)
                        }else{
                              vm.cur = 0;
                              vm.showApiDetail(1)
                        }
				}).catch(function(error){

				})
			},
			toggle:function(){
                  vm.isTrue = !vm.isTrue;
                  vm.isFalse = !vm.isFalse
			},
			sideScaling:function(){
                this.isScaling = !this.isScaling
			},
			adminAccount:function(){
				location.href = vm.ApiUrl+"/adminPage.html";
			},
			ApiUrls:function(){
				var href = document.location.href
				var index =href.lastIndexOf("\/")
				var hrefs = href .substring( 0,index);
				this.ApiUrl = hrefs;
			},
			logOutApi:function(){
					vm.isloading = true;
					axios.get(this.ApiUrl+"/logout.do ",{headers:header}).then(function (res) {
						vm.sessionTimeOut(res);
						vm.isloading = false;
						if(res.data=="SUCCESS"){
							location.href=vm.ApiUrl+"/login.html";
						}
					}).catch(function (error) {
						console.log(error);
					});
			},
			changePassword:function(){
				location.href = this.ApiUrl+"/changePassWord.html";
			},
			wholeApi:function(api,commomData){
			    for(var i=0;i<api.body.length;i++){
			        for(var list in api.body[i]){
			            if(!api.body[i][list]){
			                    if(api.body[i].antiTab=="AntiAdress"){
			                        alert("The "+list+" in Address Validation cannot be empty.")
			                    }else if(api.body[i].antiTab=="AntiFraud"){
                                    alert("The "+list+" in Anti-fraud cannot be empty.")
			                    }else if(api.body[i].antiTab=="UM"){
                                    alert("The "+list+" in Black Agent cannot be empty.")
			                    }else if(api.body[i].antiTab=="MBA"){
			                        alert("The "+list+" in Concentration Risk cannot be empty.")
			                    }
                               return;
                        }
			        }
			    }
			    for(var key in commomData){
                            if(key!="Home city"&&key!="Home address"&&key!="Company city"&&key!="Company address"){
                                   if(!commomData[key]){
                                       alert("The "+key+" cannot be empty");
                                       return;
                                   }else if(key=="ID number"){
                                            var re= /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
                                   if(!re.test(commomData[key])){
                                       			alert("The ID number is not the right format");
                                       			return;
                                   }
                             }else if(key=="Phone number"){
                                       		var re = /^1\d{10}$/
                                  if (!re.test(commomData[key])){
                                                alert("The phone number is not the right format");
                                                return;
                                  }
                             }
                      }
                }
			    var dataJsonD = [];
			    var AntiFraud = {};
			    var blackAgent = {};
			    var concentrationRisk = {};
			    var AntiAdress = {};
			    AntiFraud.request_type = api.body[0].Method;
                AntiFraud.datetime =  api.body[0].datetime;
                AntiFraud.key =  api.body[0].key;
                AntiFraud.reqid =  api.body[0].reqid;
                AntiFraud.service_id =  api.body[0].service_id;
                AntiFraud.sign_type =  api.body[0].sign_type;
                AntiFraud.sp_no =  api.body[0].sp_no;
                AntiFraud.request_url =  api.body[0].url;
                AntiFraud.name = commomData.Name;
                AntiFraud.phone = commomData['Phone number'];
                AntiFraud.identity = commomData["ID number"];

				AntiAdress.sp_no = api.body[1].sp_no;
				AntiAdress.sign_type = api.body[1].sign_type;
				AntiAdress.key = api.body[1].key;
				AntiAdress.reqid = api.body[1].reqid;
                AntiAdress.datetime = api.body[1].datetime;
			    AntiAdress.request_url = api.body[1].url;
			    AntiAdress.request_type = api.body[1].Method;
			    AntiAdress.id_type = api.body[1].id_type;
				AntiAdress.name = commomData.Name;
				AntiAdress.phone = commomData['Phone number'];

                blackAgent.request_type = api.body[2].Method;
                blackAgent.datetime = api.body[2].datetime;
                blackAgent.key = api.body[2].key;
                blackAgent.reqid = api.body[2].reqid;
                blackAgent.service_id = api.body[2].service_id;
                blackAgent.sign_type = api.body[2].sign_type;
                blackAgent.sp_no = api.body[2].sp_no;
                blackAgent.request_url = api.body[2].url;
                blackAgent.name = commomData.Name;
                blackAgent.phone = commomData['Phone number'];
                blackAgent.identity = commomData["ID number"];
                blackAgent.apiType="UM";
                concentrationRisk.request_type = api.body[3].Method;
                concentrationRisk.datetime = api.body[3].datetime;
                concentrationRisk.key = api.body[3].key;
                concentrationRisk.reqid = api.body[3].reqid;
                concentrationRisk.service_id = api.body[3].service_id;
                concentrationRisk.sign_type = api.body[3].sign_type;
                concentrationRisk.sp_no = api.body[3].sp_no;
                concentrationRisk.request_url = api.body[3].url;
                concentrationRisk.name = commomData.Name;
                concentrationRisk.phone = commomData['Phone number'];
                concentrationRisk.identity = commomData["ID number"];
                concentrationRisk.apiType="MBA";
                dataJsonD.push(concentrationRisk);
                dataJsonD.push(blackAgent);
                vm.vueClass.isActive = false;
                if(api.id==1){
                   vm.res.id = 4;
                   var antiFraudArry = [];
                   axios.post(this.ApiUrl+"/userRisk/getUserInfo.do",AntiFraud,{headers:header}).then(function (res) {
                        vm.sessionTimeOut(res);

                                    	//vm.res.body = res.data;
                                    	antiFraudArry.push(res.data);
                                    	vm.res.Ant = res.data;
                                    	vm.vueClass.isActive = true;
                                    	axios.get("./css/blackReason.json",{headers:header}).then(function(result){
                                    	var blackReason = result.data.blackReason;
                                    	var blackLevel = result.data.blackLevel;
                                    	for(var bLkey in blackLevel){
                                    			for(var subBLKey in blackLevel[bLkey]){
                                    										if(res.data.result.blackLevel == subBLKey){
                                    											vm.res.blackLevel = res.data.result.blackLevel + "   ("+blackLevel[bLkey][subBLKey][0]+")"
                                    										}
                                    									}
                                    								}
                                    								for(var bRkey in blackReason){
                                    									for(var subBRKey in blackReason[bRkey]){
                                    										if(res.data.result.blackReason == subBRKey){
                                    											vm.res.blackReason = res.data.result.blackReason + "   ( "+blackReason[bRkey][subBRKey][1]+")"
                                    										}
                                    									}
                                    								}
                                    							}).catch(function(error){
                                    								console.log(error);
                                    							})
                                    						if(res.data.result.blackDetails){
                                    							vm.res.blackDetails = JSON.parse(res.data.result.blackDetails)
                                    						}else{
                                    							vm.res.blackDetails = "";
                                    						}
                      }).catch(function (error) {
                             setTimeout(function(){vm.vueClass.isActive = true;},500);
                      });
                      axios.post(this.ApiUrl+"/userRisk/getUMandMBA.do",dataJsonD,{headers:header}).then(function (res) {
                                                          	vm.sessionTimeOut(res);

                                                          	var dataArry = [];
                                                          	if(res.data.UM){
                                                                    dataArry.push(JSON.parse(res.data.UM));
                                                                    vm.res.UM = JSON.parse(res.data.UM)
                                                              }
                                                          	if(res.data.MBA){
                                                          	    dataArry.push(JSON.parse(res.data.MBA));
                                                          	    vm.res.MBA = JSON.parse(res.data.MBA);

                                                          	    vm.wholeRisk(res.data.MBA)
                                                              }
                                                          antiFraudArry.push(dataArry);
                                                          	vm.vueClass.isActive = true;
                                                          }).catch(function (error) {
                                                          	console.log(error);
                                                          	setTimeout(function(){vm.vueClass.isActive = true;},500);
                      });
                      vm.res.body = antiFraudArry
                }else if(api.id==2){

                    AntiAdress.id_no = commomData["ID number"];
                    if(!((commomData["Home city"]&&commomData["Home address"])||(commomData["Company city"]&&commomData["Company address"]))){
                    	    alert("please must enter home address or company address");
                    	    setTimeout(function(){vm.vueClass.isActive = true;},500);
                    	    return;
                    }
                    AntiAdress.home_city= commomData["Home city"];
                    AntiAdress.home_address= commomData["Home address"];
                    AntiAdress.company_city= commomData["Company city"];
                    AntiAdress.company_address= commomData["Company address"];
                    vm.vueClass.isActive = false;

                    vm.res.body = "";
                    vm.res.addressH ="";
                    vm.res.addressC="";
                    vm.res.blackDetails="";
                    axios.post(this.ApiUrl+"/userRisk/getUserAddress.do",AntiAdress,{headers:header}).then(function (res) {
                    vm.sessionTimeOut(res);
                    vm.res.id = 2;
                    vm.res.body = res.data;
                    //vm.res.body = {"retCode":0,"retMsg":"OK","result":{"home_address_list":[{"verify_result":"","confidence":"","validity":true,"match_level":"","frequency":"","inactiveDay":""}],"home_bdcom_address_list":[{"verify_result":"","confidence":"","validity":true,"match_level":"","frequency":"","inactiveDay":""}],"company_address_list":[{"verify_result":"","confidence":"","validity":false,"match_level":"","frequency":"","inactiveDay":""}],"company_bdhome_address_list":[{"verify_result":"","confidence":"","validity":false,"match_level":"","frequency":"","inactiveDay":""}],"home_company_address_list":null}}
                    	vm.vueClass.isActive = true;
                    }).catch(function (error) {
                    	console.log(error);
                    	setTimeout(function(){vm.vueClass.isActive = true;},500);
                    });
                }
			},
			wholeRisk:function(data){
			    $("#concentrationRisk").empty();
                var dataMBA = JSON.parse(data);
                if(dataMBA.result){
                	var dataQuery = dataMBA.result
                }else{
                var html="<div class=\"row\">No detail</div>"
                    $("#concentrationRisk").append(html)
                	return;
                }
                var describe={"7d":"0-7天","15d":"8-15天","30d":"16-30天","3m":"31-90天","6m":"91-180天","12m":"181-365天",">12m":"365天以上"}
                for(var key in dataQuery){
                    console.log(dataQuery)
                    var html = "<div class=\"row\">"+
                                    "<div class=\"col-md-1\"><p class=\"refLabel\">by "+key+"</p></div>"
                                    if(dataQuery[key].values[0]){
                                        html +="<div class=\"col-md-3\"><p class=\"refLabel\">score</p><p class=\"firstValue\">"+dataQuery[key].values[0]+"</p></div>"
                                    }else{
                                        html+="<div class=\"col-md-3\"><p class=\"refLabel\">score</p><p class=\"firstValue\"></p></div>"
                                    }
                                    if(dataQuery[key].values[1]){
                                        for(var queryKey in JSON.parse(dataQuery[key].values[1])){
                                            html+="<div class=\"col-md-4\"><p class=\"retLabel\">matched details</p><p class=\"secondValue\">"+describe[queryKey]+"有"+JSON.parse(dataQuery[key]["values"][1])[queryKey]+"次多头查询</p></div>"
                                        }
                                    }else{
                                        html+="<div class=\"col-md-4\"><p class=\"retLabel\">matched details</p><p class=\"secondValue\"></p></div>"
                                    }
                                    html+="<div class=\"col-md-2\"><p class=\"retLabel\" onmouseenter='detail("+dataQuery[key].values[2]+")'><a href='#'>Mloan details</a></p></div></div>"
                    $("#concentrationRisk").append(html)
                }
			},
			detail:function(data,flg){
			    console.log(data)
			    $("#detail").empty();
			    //vm.isShowDetail = !vm.isShowDetail;
			    vm.isShowDetail = true;
			    if(flg=="Anti"){
			        if(data.length==0){
			            var html="<div class=\"row\">No detail</div>"
			            $("#detail").append(html);
			            return;
			        }
			        for(var key in data){
			            for(var subKey in data[key][0]){
			                var html = "<div><p class=\"dutyLabel\">"+subKey+"</p><p class=\"dutyValue\">"+data[key][0][subKey]+"</p></div>"
			                $("#detail").append(html);
			            }
			        }
			    }else if(flg=="UM"){
                    if(data.length==0){
                        var html="<div class=\"row\">No detail</div>"
                        $("#detail").append(html);
                        return
                    }
                     for(var key in data){
                    	 var html = "<div><p class=\"dutyLabel\">"+key+"</p><p class=\"dutyValue\">"+data[key]+"</p></div>"
                    	 $("#detail").append(html);
                    }
			    }else if(flg=="Address"){
			         if(!data){
                    		var html="<div class=\"row\">No detail</div>"
                    		$("#detail").append(html);
                    		 return;
                     }
                     for(var i=0;i<data.length;i++){
                            for(var key in data[i]){
                              var html = "<div><p class=\"dutyLabel\">"+key+"</p><p class=\"dutyValue\">"+data[i][key]+"</p></div>"
                              $("#detail").append(html);
                            }
                     }
			    }
			},
			sessionTimeOut:function(res){
				if(res.data==""&&res.headers.sessionstatus=="TIMEOUT"){
								alert("Your session has expired, please login again");
								location.href =res.headers.contextpath;
								return;
				}
			},
			filterUperCase:function(str){
                    var array = str.toLowerCase().split(" ");
                    for (var i = 0; i < array.length; i++){
                        array[i] = array[i][0].toUpperCase() + array[i].substring(1, array[i].length);
                    }
                    var string = array.join(" ").replace(/_/g, " ");
                    return string;
			},
			showApiDetail: function(id) {
				if(id == 2){
				    vm.cur = 1;
					this.api = JSON.parse(JSON.stringify(this.api_address));
				}else if(id == 1){
				    vm.cur = 0;
					 this.api = JSON.parse(JSON.stringify(this.api_whole));
				}
                 for(var resKey in this.res){
                	 this.res[resKey] = "";
                 }
			},
			reset:function(){
			    for(var resKey in this.res){
			        this.res[resKey] = "";
			    }
			    for(var comKey in this.commomData){
                	this.commomData[comKey] = "";
                }
			},
			dropdownShow:function(id){
				if(id =="config"){
					if(vm.api.config.configShow==true){
						vm.api.config.isShow = true;
						vm.api.config.isClosed = false;
						vm.api.config.configShow = false;
					}else{
						vm.api.config.isShow = false;
						vm.api.config.isClosed = true;
						vm.api.config.configShow = true;
					}
				}else if(id=="text"){
					if(vm.api.textShow.textShow==true){
						vm.api.textShow.isShow = true;
						vm.api.textShow.isClosed = false;
						vm.api.textShow.textShow = false;
					}else{
						vm.api.textShow.isShow = false;
						vm.api.textShow.isClosed = true;
						vm.api.textShow.textShow = true;
					}
				}
			}
		}
	})
