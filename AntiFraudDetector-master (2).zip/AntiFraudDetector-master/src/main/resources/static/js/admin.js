 var header = {
							'Content-Type': 'application/json;charset=UTF-8',
							'cache-control': 'no-cache',
							'x-requested-with': ' XMLHttpRequest'
				}
Vue.component("tabPane",{
    template:"#demo",
    data:function(){
        return {
            list:[]
        }
    },
    props:["list"],
    methods:{
        submit:function(data){
              for(var list in data){
                    if(!data[list]&&list!="isShow"){
                        alert("The input cannot be empty");
                        return;
                    }
              }
              var dataJson = data;
              vm.isLoading = true;
              axios.post(vm.ApiUrl+"/updateAntiFraudConfigInfo.do",dataJson,{headers:header}).then(function(res){
            		vm.sessionTimeOut(res);
            		vm.isLoading = false;
            		alert(res.data.message)
            		vm.APIConfig();
              }).catch(function(error){
                    console.log(error)
              })
        }
    }
})
 var vm = new Vue({
                el:"#adminPage",
                data:{
                    all: "", //总页数
                    cur: 1,//当前页码
                    ApiUrl:"",
                    isTrue:true,
                    isFalse:false,
                    isScaling:false,
                    isList:0,
                    APIShow:["Account Info","Log Info","Config Info"],
                    api:{
                        id:0,
                        name:"",
                        body:[]
                    },
                    isLoading:true,
                    account:{
                        id:1,
                        name:"Account Information",
                        body:[]
                    },
                    logInfo:{
                        id:2,
                        name:"Log Information",
                        body:[]
                    },
                    config:{
                        id:3,
                        name:"Config Information",
                        body:[]
                    }
                },
                created:function(){
                    this.ApiUrls();
                    this.showDetailData();
                    this.APIConfig();
                },
                watch: {
                    cur: function(oldValue , newValue){
                        console.log(arguments);
                    }
                },
                computed: {
                        indexs: function(){
                          var left = 1;
                          var right = this.all;
                          var ar = [];
                          if(this.all>= 5){
                            if(this.cur > 3 && this.cur < this.all-2){
                                    left = this.cur - 2
                                    right = this.cur + 2
                            }else{
                                if(this.cur<=3){
                                    left = 1
                                    right = 5
                                }else{
                                    right = this.all
                                    left = this.all -4
                                }
                            }
                         }
                        while (left <= right){
                            ar.push(left)
                            left ++
                        }
                        return ar
                       }

                },
                methods:{
                    currentPage: function(data){//页码点击事件
                        var logInfoData = JSON.parse(localStorage.getItem("logInfoData"));
                        if(data != this.cur){
                            this.cur = data;
                            var curruntPageData = logInfoData.slice((data-1)*50,data*50)
						    vm.logInfo.body =curruntPageData;
						    vm.api = JSON.parse(JSON.stringify(vm.logInfo));
                        }
                    },
                    sideScaling:function(){
                                        this.isScaling = !this.isScaling
                    },
                    changePassword:function(){
                    				location.href = this.ApiUrl+"/changePassWord.html";
                    },
                    logOutApi:function(){
                    		vm.isloading = true;
                    		axios.get(this.ApiUrl+"/logout.do ",{headers:header}).then(function (res) {
                    		vm.sessionTimeOut(res);
                    		vm.isloading = false;
                    		if(res.data=="SUCCESS"){
                    			location.href=vm.ApiUrl+"/login.html";
                    		}
                    		}).catch(function (error) {
                    			console.log(error);
                    		});
                    },
                    toggle:function(){
                        vm.isTrue = !vm.isTrue;
                        vm.isFalse = !vm.isFalse
                    },
                    backPage:function(data){
                        var logInfoData = JSON.parse(localStorage.getItem("logInfoData"));
                        if(data =="1"){
                             var curruntPageData = logInfoData.slice(0,50)
						     vm.logInfo.body =curruntPageData;
						     vm.api = JSON.parse(JSON.stringify(vm.logInfo));
						     this.cur ==1;
                        }else{
                             var curruntPageData = logInfoData.slice((vm.all-1)*50)
						     vm.logInfo.body =curruntPageData;
						     vm.api = JSON.parse(JSON.stringify(vm.logInfo));
						     this.cur == data;
                        }
                    },
                    pageClick: function(){
                        var logInfoData = JSON.parse(localStorage.getItem("logInfoData"));
                        var curruntPageData = logInfoData.slice((this.cur-1)*50,this.cur*50)
						vm.logInfo.body =curruntPageData;
						vm.api = JSON.parse(JSON.stringify(vm.logInfo));
                    },
                    sessionTimeOut:function(res){
                        if(res.data==""&&res.headers.sessionstatus=="TIMEOUT"){
                                        alert("Your session has expired, please login again");
                                        sessionStorage.setItem("account","")
                                        location.href =res.headers.contextpath;
                                        return true;
                        }
			        },
			        APIConfig:function(){
				        axios.get(this.ApiUrl+"/getAntiFraudConfigInfo.do",{headers:header})
				             .then(function(res){
					        vm.sessionTimeOut(res);
					        console.log(res)
					        var bodyList = [];
						    for(var i=0,len=res.data.length;i<len;i++){
                                var typeList = res.data[i].Method.split(";")
                                    var typeOption = [];
                                    for(var key in typeList){
                                        typeOption.push({type:typeList[key]})
                                    }
                                     var bodyObject = {};
                                        if(res.data[i].isShow=="true"){
                                             bodyObject.isShow=true
                                        }else{
                                             bodyObject.isShow=false
                                        }
                                    	 bodyObject.url=res.data[i].url;
                                         bodyObject.Method=typeList[0];
                                         bodyObject.typeOption=typeOption;
                                         bodyObject.antiTab=res.data[i].antiTab;
                                         bodyObject.sp_no=res.data[i].sp_no;
                                         bodyObject.reqid=res.data[i].reqid;
                                         bodyObject.datetime=res.data[i].datetime;
                                         bodyObject.sign_type=res.data[i].sign_type;
                                         bodyObject.key="123456";
                                      if(res.data[i].antiTab=="AntiAdress"){
                                            bodyObject.id_type=res.data[i].id_type
                                      }else{
                                            bodyObject.service_id=res.data[i].service_id
                                      }
                                 bodyList.push(bodyObject)
						    }
						   vm.config.body = bodyList
						    console.log(bodyList)
				        }).catch(function(error){

				        })
			        },
                    backIndex:function(){
                         location.href = this.ApiUrl+"/index.html";
                    },
                    ApiUrls:function(){
				        var href = document.location.href
                        var index =href.lastIndexOf("\/")
                        href = href .substring( 0,index);
                        this.ApiUrl = href;
			        },
                    showDetailData:function(){
                        axios.get(this.ApiUrl+"/getAllUserInfo.do",{headers:header})
                             .then(function(res){
						     vm.sessionTimeOut(res);
						     vm.account.body = res.data;
						     vm.isLoading = false;
                             vm.showDetail(1);
                        }).catch(function(error){
                              console.log(error)
                        })
                    },
                    showDetail:function(id){
                        if(id==1){
                            vm.isList = 0;
                             vm.api = JSON.parse(JSON.stringify(vm.account));
                        }else if(id==2){
                            vm.isList =1;
                            vm.isLoading = true;
                            axios.get(this.ApiUrl+"/getUserLogInfo.do",{headers:header}).then(function(res){
						            vm.sessionTimeOut(res);
                                    vm.isLoading = false;
						            var logInfoData = [];
						            for(var i=0;i<res.data.length;i++){
						                  var list = {
						                        "Account":res.data[i].account,
						                         "Action":res.data[i].action,
						                         "ip":res.data[i].IP,
                                                 "result":res.data[i].result,
                                                "time":res.data[i].time,
                                                "HostName":res.data[i].hostName
						                  }
						                  logInfoData.push(list);
						            }
						            console.log(logInfoData);
						            vm.all = Math.ceil(logInfoData.length/50);
						            localStorage.setItem("logInfoData",JSON.stringify(logInfoData))
						            var curruntPageData = logInfoData.slice(0,50)
						            vm.logInfo.body =curruntPageData;
						             vm.api = JSON.parse(JSON.stringify(vm.logInfo));
                            }).catch(function(error){
                            })
                        }else if(id==3){
                            vm.isList = 2;
                            vm.api = JSON.parse(JSON.stringify(vm.config));
                        }
                    },
                    handleMethods:function(account,flag){
                        if(flag =="delete"){
                            var deleteData = account;
                            axios.post(this.ApiUrl+"/deleteUserInfo.do",deleteData,{headers:header}).then(function (res) {
                                   vm.sessionTimeOut(res);
                                    if(res.data.flag =="SUCCESS"){
                        		        alert(res.data.message);
                        		        vm.showDetailData("delete");
                        	        }else if(res.data.flag =="FAIL"){
								        alert(res.data.message);
                        	        }
                                }).catch(function (error) {
                                        console.log(error);
                            });
                        }else{
                             var changeData = {
                                    account:account,
                                    flag:flag,
                                }
                         axios.post(this.ApiUrl+"/updateUserInfoStatus.do",changeData,{headers:header}).then(function (res) {
                                    vm.sessionTimeOut(res);
                        	        if(res.data.flag =="SUCCESS"){
                        		        alert(res.data.message);
                        		        vm.showDetailData("confirm");
                        	        }else if(res.data.flag =="FAIL"){
								        alert(res.data.message);
                        	        }
                                }).catch(function (error) {
                                        console.log(error);
                                });
                        }
                    }
                }
 })