
$(".sideHide").click(function(){
	var show = $(this).attr("id")
	if(show =="active"){
		$(".main").css("margin-left","-12.5rem")
		$(".sideShow").hide();
		$(this).attr("id","")
	}else{
		$(".main").css("margin-left","-1.5rem")
		$(".sideShow").show();
		$(this).attr("id","active")
	}	
})
$(".dropdownBar").mouseenter(function(){
	$(this).addClass("dropdownLight");
	$(this).children().css("color","#333")
})
$(".dropdownBar").mouseleave(function(){
	$(this).removeClass("dropdownLight");
	$(this).children().css("color","#333");
})
$(".dropdownBar").click(function(){
	var showId = $(this).attr("id");
	if(showId =="active"){
		$(this).children().eq(1).addClass("glyphicon-chevron-down").removeClass("glyphicon-chevron-up");
		$(this).removeClass("dropdownClick").addClass("dropdownLight");

		$(this).children().css("color","#333")
		$(".dropdownList").hide();
		$(this).attr("id","")
	}else{
		$(this).children().eq(1).addClass("glyphicon-chevron-up").removeClass("glyphicon-chevron-down");
		$(this).addClass("dropdownClick").removeClass("dropdownLight");
		$(".dropdownList").show();
		$(this).attr("id","active");
	}
	$(this).children().css("color","#333");
})
$(".dropdownList").on("click","li",function(){
	$(this).parent().siblings(".dropdownBar").children().css("color","#333");
	$(this).addClass("dropdownLi").siblings().removeClass("dropdownLi");
})
