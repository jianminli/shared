package com.pycredit.api.gateway.demo;

import com.alibaba.fastjson.JSON;
import com.pycredit.api.gateway.demo.bean.QueryCondition;
import com.pycredit.api.gateway.demo.bean.QueryConditions;
import com.pycredit.api.gateway.demo.config.PyConfig;
import com.pycredit.api.gateway.demo.util.HttpUtils;
import com.pycredit.api.gateway.demo.util.PyUtils;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 调用示例
 */
public class PyApiDemo {

    @Test
    public void requestUnzipApi() throws Exception {
        String result = requestApi(PyConfig.HOST, PyConfig.PATH_UNZIP);
        System.out.println(result);
    }

    //    @Test
    public void requestZipApi() throws Exception {
        String result = requestApi(PyConfig.HOST, PyConfig.PATH_ZIP);
        System.out.println(result);

        // 对压缩文本做进一步处理
        Map<String, Object> resultMap = JSON.parseObject(result);
        String status = (String) resultMap.get("status");
        if ("1".equals(status)) {
            String returnValue = (String) resultMap.get("returnValue");
            returnValue = PyUtils.decodeAndDecompress(returnValue, "UTF-8");
            System.out.println("returnValue:" + returnValue);
        }
    }

    public static String requestApi(String host, String path) throws Exception {

        // https双向认证使用,配合PySSLContextUtil中的DefaultSSLContext
//        System.setProperty("javax.net.debug", "all");
//        System.setProperty("javax.net.ssl.keyStore", PyConfig.KEYSTORE_FILE);
//        System.setProperty("javax.net.ssl.keyStorePassword", PyConfig.KEYSTORE_PASSWORD);
//        System.setProperty("javax.net.ssl.trustStore", PyConfig.TRUSTSTORE_FILE);
//        System.setProperty("javax.net.ssl.trustStorePassword", PyConfig.TRUSTSTORE_PASSWORD);

        Map<String, String> headers = new HashMap<String, String>();
        Map<String, String> querys = null;
        Map<String, String> bodys = new HashMap<String, String>();
		//默认请求条件是JSON格式.如果请求条件是xml，需要指定格式。
		//bodys.put("format","xml")
        bodys.put("userID", PyConfig.USERID);
        bodys.put("password", PyConfig.PASSWORD);
        bodys.put("queryCondition", getQueryCondition());
        HttpResponse response = HttpUtils.doPost(host, path, "POST", headers, querys, bodys);
        String result = EntityUtils.toString(response.getEntity());

        return result;
    }

    private static String getQueryCondition() throws Exception {

        if (PyConfig.IS_TEST) {
            // 读取文件方式（测试使用,仅供参考）
            return PyUtils.toString(new FileInputStream(PyConfig.QUERY_FILE), "UTF-8");
        } else {
            // 使用JavaBean/Map方式（正式使用,仅供参考）
            QueryConditions queryConditions = new QueryConditions();
            List<QueryCondition> conditions = new ArrayList<QueryCondition>();
            QueryCondition queryCondition = new QueryCondition();
            // 查询类型
            queryCondition.setQueryType("25123");
            List<QueryCondition.Item> items = new ArrayList<QueryCondition.Item>();
            // 收费子报告
            items.add(new QueryCondition.Item("subreportIDs", "21301"));
            // 查询原因
            items.add(new QueryCondition.Item("queryReasonID", "101"));
            // 业务流水号
            items.add(new QueryCondition.Item("refID", ""));
            // 具体查询条件
            items.add(new QueryCondition.Item("corpName", "鹏元征信有限公司"));

            queryCondition.setItems(items);
            conditions.add(queryCondition);
            queryConditions.setConditions(conditions);
            return JSON.toJSONString(queryConditions);
        }

    }
}
