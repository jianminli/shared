# 鹏元征信接口调用Demo

1. 鹏元接口调用请参考接口文档和PyApiDemo.java
   - 请求文件的内容可通过JAVA对象组装，再将对象转化成字符串传参
   - 请求文件的具体字段请参考接口文档

2. 鹏元接口配置请参考PyConfig.java

3. 鹏元接口https双向认证，创建SSLContext有两种方式
   - 使用PySSLContextUtil.createDefaultSSLContext,该方式读取的是系统默认证书路径，可加上如下代码指定证书路径
```
      System.setProperty("javax.net.ssl.keyStore", PyConfig.KEYSTORE_FILE);
      System.setProperty("javax.net.ssl.keyStorePassword", PyConfig.KEYSTORE_PASSWORD);
      System.setProperty("javax.net.ssl.trustStore", PyConfig.TRUSTSTORE_FILE);
      System.setProperty("javax.net.ssl.trustStorePassword", PyConfig.TRUSTSTORE_PASSWORD);
```
   - 使用PySSLContextUtil.createCustomerSSLContext,该方式读取的是指定证书路径