package com.pycredit.api.gateway.demo.config;

/**
 *
 */
public class PyConfig {

    // API域名
    public final static String HOST = "https://test.pycredit.com:6443"; // 测试环境
//    public final static String HOST = "https://www.pycredit.com:6443"; // 生产环境

    // 返回报文压缩的URL
    public final static String PATH_ZIP = "/rest/query/report/zip";

    // 返回报文不压缩的URL
    public final static String PATH_UNZIP = "/rest/query/report/unzip";

    // 认证信息
    public final static String USERID = "";
    public final static String PASSWORD = "";

    // 是否测试模式
    public final static boolean IS_TEST = false;

    // 请求内容样本文件，实际中可使用具体对象组装
    public final static String QUERY_FILE = "/sample.json";

    public final static String KEYSTORE_FILE = "d:/certs/client.jks";
    public final static String KEYSTORE_PASSWORD = "123456";
    public final static String TRUSTSTORE_FILE = "d:/certs/client.jks";
    public final static String TRUSTSTORE_PASSWORD = "123456";
}
